﻿using Lab8.EF.ZadB.Models;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab8.EF.ZadB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DbUczelnia db = new DbUczelnia();
        List<Student> students = new List<Student>();
        private void btn_Wyswietl_Click(object sender, RoutedEventArgs e)
        {
            Wyswietl();
        }
        public void Wyswietl()
        {
            foreach (var student in db.Studenci)
            {
                students.Add(student);
                lbx_lista.Items.Add(student.ToString());
            }
            lbl_srednia.Content = students.Average(s => s.Ocena);
        }
        private void btn_Dodaj_Click(object sender, RoutedEventArgs e)
        {
            string nazwisko = tbx_Nazwisko.Text;
            string imie = tbx_Imie.Text;
            double? ocena = Convert.ToDouble(tbx_Ocena.Text);
            byte wiek = Convert.ToByte(tbx_Wiek.Text);
            Student student = new Student() {Imie = imie, Nazwisko = nazwisko, Wiek = wiek, Ocena = ocena};
            db.Add(student);
            lbx_lista.Items.Clear();
            Wyswietl();
        }
    }
}