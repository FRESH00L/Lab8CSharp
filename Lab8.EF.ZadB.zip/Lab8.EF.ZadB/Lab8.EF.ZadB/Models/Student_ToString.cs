﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8.EF.ZadB.Models
{
    public partial class Student
    {
        public override string ToString()
        {
            return $"{Imie} {Nazwisko}, {Wiek}: {(Ocena?.ToString() ?? "Brak")}";
        }
    }
}
