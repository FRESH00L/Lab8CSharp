﻿using Microsoft.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Data;
using Microsoft.Data.SqlClient;

namespace Lab8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Wyswietl_Click(object sender, RoutedEventArgs e)
        {
            using (var polaczenie = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Sklep;
                    Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;
                    Application Intent=ReadWrite;Multi Subnet Failover=False"))
            {
                var polecenie = new SqlCommand("SELECT * FROM Towary", polaczenie);
                polaczenie.Open();
                SqlDataReader czytnik = polecenie.ExecuteReader();
                while (czytnik.Read()) 
                {
                    string dane = $"{czytnik["Nazwa"]}, {czytnik["Cena"]}zł, {czytnik["Ilosc"]} szt.";
                    lbx_dane.Items.Add(dane);
                }
                czytnik.Close();
                polecenie = new SqlCommand("SELECT AVG(Cena) FROM Towary", polaczenie);
                decimal srednia = (decimal)polecenie.ExecuteScalar();
                lbl_average.Content = $"średnia cena: {srednia:C}";
                polaczenie.Close();
            }
        }
    }
}